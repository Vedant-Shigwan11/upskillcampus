from flask import Flask, render_template, redirect, url_for, request, session, flash
from models import db, Product
from config import Config

# ────────────────────────────
# App / Config / Extensions
# ────────────────────────────
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 🔐 Required for session & flash messages
app.config.from_object(Config)          # 1️⃣ Load ALL config in one go
db.init_app(app)                        # 2️⃣ Initialise SQLAlchemy

# ────────────────────────────
# Ensure tables exist (first run)
# ────────────────────────────
with app.app_context():
    db.create_all()

# Dummy user
users = {'Admin@123': 'password123'}

# ────────────────────────────
# ROUTES
# ────────────────────────────
@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/register')
def register():
    return "<h1>Register page coming soon.</h1>"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if users.get(email) == password:
            session['user'] = email
            flash('Logged in successfully!', 'success')
            return redirect(url_for('shop'))
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('login'))

@app.route('/shop')
def shop():
    products = Product.query.all()
    return render_template('shop.html', products=products)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    quantity = int(request.form['quantity'])
    product = Product.query.get_or_404(product_id)

    # Use string keys to make it JSON-serializable
    cart = session.get('cart', {})
    product_id_str = str(product_id)
    
    if product_id_str in cart:
        cart[product_id_str] += quantity
    else:
        cart[product_id_str] = quantity

    session['cart'] = cart  # Save updated cart
    flash(f'Added {quantity} x {product.name} to cart.', 'success')
    return redirect(url_for('shop'))

@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    cart = session.get('cart', {})
    product_id_str = str(product_id)

    if product_id_str in cart:
        cart.pop(product_id_str)
        session['cart'] = cart
        flash('Item removed from cart.', 'info')
    else:
        flash('Item not found in cart.', 'warning')

    return redirect(url_for('cart'))

@app.route('/cart')
def cart():
    cart_dict = session.get('cart', {})
    cart_items = []
    total_amount = 0
    total_items = 0

    for pid_str, qty in cart_dict.items():
        pid = int(pid_str)
        product = Product.query.get(pid)
        if product:
            subtotal = qty * product.price
            cart_items.append({
                'id': product.id,
                'name': product.name,
                'qty': qty,
                'subtotal': subtotal
            })
            total_amount += subtotal
            total_items += qty

    return render_template(
        'cart.html',
        cart_items=cart_items,
        total_items=total_items,
        total_amount=total_amount
    )

@app.route('/payment', methods=['GET', 'POST'])
def payment():
    if request.method == 'POST':
        session['payment_method'] = request.form['payment_method']
        flash(f"Payment method selected: {session['payment_method']}", 'success')
        return redirect(url_for('delivery'))
    return render_template('payment.html')

@app.route('/delivery', methods=['GET', 'POST'])
def delivery():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'place':
            # ✅ Show message & go to feedback
            flash('Order placed successfully!', 'success')
            return redirect(url_for('feedback'))
        elif action == 'cancel':
            return redirect(url_for('shop'))
    return render_template('delivery.html')

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        rating = int(request.form['rating'])
        message = request.form['message']
        flash('Thanks for your feedback!', 'success')
        return redirect(url_for('feedback'))

    # On GET: keep only order/feedback related messages
    allowed_messages = {'Order placed successfully!', 'Thanks for your feedback!'}
    flashes = session.get('_flashes', [])
    filtered = [f for f in flashes if f[1] in allowed_messages]
    session['_flashes'] = filtered

    return render_template('feedback.html')

# ────────────────────────────
# Main entry
# ────────────────────────────
if __name__ == '__main__':
    app.run(debug=True)
