from app import app, db, Product

with app.app_context():
    db.create_all()
    if Product.query.count() == 0:
        default_products = [
            Product(name='Apples', price=60.0, quantity=50),
            Product(name='Bananas', price=30.0, quantity=100),
            Product(name='Tomatoes', price=25.0, quantity=80),
            Product(name='Potatoes', price=20.0, quantity=120),
            Product(name='Milk 1L', price=50.0, quantity=40),
            Product(name='Bread', price=25.0, quantity=60),
            Product(name='Onions', price=35.0, quantity=90),
            Product(name='Garlic', price=150.0, quantity=30),
            Product(name='Ginger', price=80.0, quantity=40),
            Product(name='Carrots', price=45.0, quantity=70),
            Product(name='Cabbage', price=30.0, quantity=60),
            Product(name='Cauliflower', price=40.0, quantity=50),
            Product(name='Spinach', price=20.0, quantity=100),
            Product(name='Coriander', price=15.0, quantity=80),
            Product(name='Green Chillies', price=60.0, quantity=40),
            Product(name='Capsicum', price=50.0, quantity=60),
            Product(name='Cucumber', price=25.0, quantity=90),
            Product(name='Beetroot', price=40.0, quantity=40),
            Product(name='Brinjal', price=35.0, quantity=50),
            Product(name='Lettuce', price=30.0, quantity=30),
            Product(name='Pumpkin', price=28.0, quantity=45),
            Product(name='Radish', price=22.0, quantity=60),
            Product(name='Sweet Corn', price=35.0, quantity=40),
            Product(name='Mushroom', price=120.0, quantity=25),
            Product(name='Peas', price=55.0, quantity=60),
            Product(name='Bitter Gourd', price=30.0, quantity=40),
            Product(name='Bottle Gourd', price=26.0, quantity=50),
            Product(name='Drumsticks', price=40.0, quantity=30),
            Product(name='Zucchini', price=70.0, quantity=20),
            Product(name='Spring Onion', price=30.0, quantity=35),
            Product(name='Turnip', price=27.0, quantity=40),
            Product(name='Fenugreek Leaves', price=18.0, quantity=50),
            Product(name='Green Beans', price=45.0, quantity=60),
            Product(name='Parwal', price=32.0, quantity=50),
            Product(name='Yam', price=48.0, quantity=30),
            Product(name='Raw Banana', price=20.0, quantity=60),
            Product(name='Tinda', price=22.0, quantity=55)
        ]
        db.session.bulk_save_objects(default_products)
        db.session.commit()
        print("Default products added.")
    else:
        print("Products already exist.")
